# Biblioteca Universitária - Projeto Integrador

Resumo rápido
Sistema para gerenciar catálogo de PDFs e registrar empréstimos. Frontend estático servido via IIS; API em Python/Flask para listagem e registro.

Estrutura do repositório
- index.html, catalogo.html, admin.html - front-end
- flask_app.py - API Flask (endpoints: /pdf_list, /courses, /pdfs/<file>, /loan, /loans)
- pdfs/ - PDFs and metadata.csv
- data/loans.csv - registros de empréstimos (CSV)
- requirements.txt - dependências Python
- web.config - arquivo básico para IIS
- docs/DOCUMENTACAO.pdf - documentação resumida

Como rodar (VM Windows Server)
1. Copie a pasta para C:\biblioteca_site na VM Windows Server.
2. Instale Python 3.11 e dependências:
   python -m pip install -r requirements.txt
3. Rode o Flask (teste):
   python flask_app.py
4. Verifique as rotas:
   http://localhost:5000/pdf_list
   http://localhost:5000/courses
   http://localhost:5000/loans

Configure IIS para servir C:\biblioteca_site como site com binding em porta 80; habilite Directory Browsing para /pdfs.
