from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import os, csv

app = Flask(__name__)
CORS(app)

BASE = r"C:\biblioteca_site"
PDF_FOLDER = os.path.join(BASE, "pdfs")
DATA_DIR = os.path.join(BASE, "data")
LOANS_FILE = os.path.join(DATA_DIR, "loans.csv")
METADATA_FILE = os.path.join(PDF_FOLDER, "metadata.csv")

os.makedirs(PDF_FOLDER, exist_ok=True)
os.makedirs(DATA_DIR, exist_ok=True)
if not os.path.exists(LOANS_FILE):
    with open(LOANS_FILE, "w", encoding="utf-8") as f:
        f.write("name,pdf,date\n")

def read_metadata():
    metas = []
    if not os.path.exists(METADATA_FILE):
        return metas
    with open(METADATA_FILE, newline='', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            metas.append(row)
    return metas

@app.get("/courses")
def get_courses():
    metas = read_metadata()
    courses = sorted(set(m.get('course','') for m in metas if m.get('course')))
    return jsonify(courses)

@app.get("/pdf_list")
def pdf_list():
    course = request.args.get('course', None)
    metas = read_metadata()
    result = []
    if metas:
        for m in metas:
            fn = m.get('filename')
            if not fn: continue
            if course and course != "" and m.get('course') != course:
                continue
            result.append({"filename": fn, "course": m.get('course', ''), "author": m.get('author','')})
    else:
        files = [f for f in os.listdir(PDF_FOLDER) if f.lower().endswith('.pdf')]
        for f in files:
            result.append({"filename": f, "course": "", "author": ""})
    return jsonify(result)

@app.route("/pdfs/<path:filename>")
def pdf(filename):
    return send_from_directory(PDF_FOLDER, filename)

@app.route("/loan", methods=["POST"])
def loan():
    data = request.get_json()
    if not data or "name" not in data or "pdf" not in data:
        return jsonify({"error":"dados inválidos"}), 400
    with open(LOANS_FILE, "a", encoding="utf-8") as f:
        f.write(f'{data.get("name","")},{data.get("pdf","")},{data.get("date","")}\n')
    return jsonify({"status":"ok"})

@app.get("/loans")
def loans():
    rows = []
    with open(LOANS_FILE, encoding="utf-8") as f:
        next(f, None)
        for line in f:
            parts = line.rstrip("\\n").split(",", 2)
            if len(parts) == 3:
                name,pdf,date = parts
            else:
                name = parts[0] if parts else ""
                pdf = parts[1] if len(parts)>1 else ""
                date = parts[2] if len(parts)>2 else ""
            rows.append({"name":name,"pdf":pdf,"date":date})
    return jsonify(rows)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
